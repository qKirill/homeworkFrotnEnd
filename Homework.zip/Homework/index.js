// const userLogin = prompt("Введіть ваш логін")

// if(userLogin === 'Admin'){
//     const userPassword = prompt("Введіть пароль")

//     userPassword === '12345' ? alert("Ласкаво просимо") : alert("Пароль невірний")
// }else{
//     alert("Доступ заблоковано")
// }

const tourNames = document.querySelectorAll('.tour-card-title')
const tourDescriptions = document.querySelectorAll('.tour-card-description')
const tourPrices = document.querySelectorAll('.tour-price')
const tourDurations = document.querySelectorAll('.tour-dration')
const tourCards = document.querySelectorAll('.tour-card')
const sectionTourCards = document.querySelector('#order-tour');


const btnsMoreInfo = document.querySelectorAll('.tour-card-button-info')
const btncloseMoreInfo = document.querySelector('.close-btn')
const btnsBuy = document.querySelectorAll('.tour-card-button-buy')
const btnSortTourCards = document.querySelector('.sort-tours-cards')

const moreInfoMenu = document.querySelector('.more-info-menu')
const mainInfoMenu = document.querySelector('.main-info-informations')
const mainBuyMenu = document.querySelector('.main-buy-informations')
const totalTourCost = document.querySelector('.total-cost-value')

const inpAmountPeople = document.querySelector('.inp-amount-people')
const inputMaxPrice = document.querySelector('.input-max-price')

const errorInput = document.querySelector('.error-input')

btncloseMoreInfo.addEventListener('click', () =>{
    moreInfoMenu.style.width = '0'
    moreInfoMenu.style.transition = '.4s'
})

const tour = {
    name: '',
    description: '',
    price: '',
    duration: ''
}

function clickAction(btnIndex){
    tour['name'] = tourNames[btnIndex].textContent
    tour['description'] = tourDescriptions[btnIndex].textContent
    tour['price'] = +(tourPrices[btnIndex].textContent)
    tour['duration'] = +(tourDurations[btnIndex].textContent)
        
    moreInfoMenu.style.width = '30rem'
    moreInfoMenu.style.transition = '.4s'

    mainInfoMenu.innerHTML = displayInfo()
        
    inpAmountPeople.value = ''
    totalTourCost.innerHTML = ''
}

btnsMoreInfo.forEach((btn, index) => {
    btn.addEventListener('click', () => {
        clickAction(index)
    })
})

btnsBuy.forEach((btn, index) => {
    btn.addEventListener('click', () => {
        clickAction(index)
    })
})

function displayInfo(){
    return `
        <p>tour name: ${tour['name']}</p>
        <p>tour description: ${tour['description']}</p>
        <p>tour price: ${tour['price']}$</p>
        <p>tour duration: ${tour['duration']}</p>
    `
}     


function calculateTotalCost(amountPeople){
    return amountPeople === '' || amountPeople <= 0 ? '': tour['price'] * amountPeople + '$'
}
inpAmountPeople.addEventListener('input', (event) => {
    totalTourCost.innerHTML = `${calculateTotalCost(event.target.value)}`
})

let minPrice = +(tourPrices[0].textContent)
tourPrices.forEach((price) => {
    minPrice >= +(price.textContent) ? minPrice = +(price.textContent) : minPrice
})

inputMaxPrice.addEventListener('input', (event) => {
    if(event.target.value === ''){
        errorInput.style.display = 'none'
        tourCards.forEach((card) => card.style.display = 'block')
        return
    }
    
    maxTourPrice(event.target.value)
})

function maxTourPrice(maxPrice){
    if(maxPrice < minPrice){
        errorInput.style.display = 'block'
    }else{
        tourPrices.forEach((price, index) => {
            maxPrice >= +(price.textContent) ? tourCards[index].style.display = 'block' : tourCards[index].style.display = 'none'
        })
        errorInput.style.display = 'none'
    }
}

let originalTourCardsArr
let sortValue = false

function sortToursCards(btnValue){
    const tourCardsArr = Array.from(sectionTourCards.querySelectorAll('.tour-card'));

    originalTourCardsArr = Array.from(tourCardsArr)

    tourCardsArr.sort((a, b) => {
        let textA = a.getElementsByClassName('tour-card-title')[0].textContent
        let textB = b.getElementsByClassName('tour-card-title')[0].textContent

        return textA.localeCompare(textB)
    })

    tourCardsArr.forEach(tourCard => sectionTourCards.removeChild(tourCard))
    tourCardsArr.forEach(tourCard => sectionTourCards.appendChild(tourCard))

    btnValue.innerHTML = 'unsort'

    sortValue = true
}

function returnOriginalPositionTourCards(btnValue){
    originalTourCardsArr.forEach(tourCard => sectionTourCards.appendChild(tourCard))
    btnValue.innerHTML = 'sort'

    sortValue = false
}

btnSortTourCards.addEventListener('click', (event) => { 
    switch (sortValue) {
        case false:
            sortToursCards(btnSortTourCards)
            break

        case true:
            returnOriginalPositionTourCards(btnSortTourCards)
            break
    
        default:
            returnOriginalPositionTourCards()
    }
})
